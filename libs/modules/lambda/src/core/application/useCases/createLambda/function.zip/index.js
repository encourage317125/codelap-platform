exports.handler = function (event, context) {
  console.log('lambda function')

  return 'Hello World'
}
